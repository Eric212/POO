import java.util.Scanner;
public class Ejercicio4{
	public static void main(String[] args) {
		Scanner lector = new Scanner(System.in);
		String frase;
		int palabras;
		System.out.println("Introduce una frase");
		frase=lector.nextLine();
		palabras=contarPalabras(frase);
		System.out.println("El numero de palabras de:\""+frase+" es:"+palabras);
	}
	static int contarPalabras(String frase){
		int consonantes=0;
		int vocales=0;
		frase=frase.trim();
		rase=frase.toLowerCase();
		String espacio=" ";
		for(int i=0;i<frase.length();i++){
			if(Character.toString(frase.charAt(i)).equals(espacio)){
				if(Character.toString(fraseObjeto.charAt(i)).compareTo("a")<0){
						vocales=0;
						consonantes=0;
					}else{
						if(Character.toString(fraseObjeto.charAt(i)).equalsIgnoreCase("a")||Character.toString(fraseObjeto.charAt(i)).equalsIgnoreCase("e")||Character.toString(fraseObjeto.charAt(i)).equalsIgnoreCase("i")||Character.toString(fraseObjeto.charAt(i)).equalsIgnoreCase("o")||Character.toString(fraseObjeto.charAt(i)).equalsIgnoreCase("u")){
							vocales++;
						}else{
							consonantes++;
						}
					}
				}else if(i==frase.length()-1){
					if(Character.toString(fraseObjeto.charAt(i)).equalsIgnoreCase("a")||Character.toString(fraseObjeto.charAt(i)).equalsIgnoreCase("e")||Character.toString(fraseObjeto.charAt(i)).equalsIgnoreCase("i")||Character.toString(fraseObjeto.charAt(i)).equalsIgnoreCase("o")||Character.toString(fraseObjeto.charAt(i)).equalsIgnoreCase("u")){
						vocales++;
					}else{
						consonantes++;
					}
			}
		}
		return palabras;
	}
}